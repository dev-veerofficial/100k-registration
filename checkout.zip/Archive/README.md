<img src="https://image.flaticon.com/icons/png/512/178/178396.png" height="50">

# Wizzy 0.6.1
A simple and modern wizard plugin

Wizzy is a simple and modern wizzy with cool UI and lots of features.

Get started
====
```html
$('.wizard').wizzy();
```
